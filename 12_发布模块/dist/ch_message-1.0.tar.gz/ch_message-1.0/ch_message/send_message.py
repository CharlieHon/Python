def send(text: str):
    print("正在发送 %s" % text)